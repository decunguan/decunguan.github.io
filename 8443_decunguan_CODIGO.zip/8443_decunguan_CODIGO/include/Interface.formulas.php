<?php
	interface formulas{
			public function area();
			public function perimetro();
		}
?>
